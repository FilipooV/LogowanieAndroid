package com.example.newactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {

    Button button1;
    EditText pass;
    TextInputLayout login;
    String Slogin;

    String Spass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = findViewById(R.id.button);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pass = findViewById(R.id.editTextTextPassword);
                Spass = pass.getText().toString();
                login = findViewById(R.id.textInputLayout2);
                Slogin = login.getEditText().getText().toString();

                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                intent.putExtra("loginKey", Slogin);

                if (Spass.matches("")){
                    Toast.makeText(MainActivity.this, "Nie wprowadzono hasła!", Toast.LENGTH_SHORT).show();
                }
                else{
                    startActivity(intent);
                }
            }
        });
    }
}